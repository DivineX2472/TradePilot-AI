export const TIMEFRAMES = ["M5", "M15", "H1", "H4"] as const;
export type Timeframe = (typeof TIMEFRAMES)[number];

export const TIMEFRAME_SECONDS: Record<Timeframe, number> = {
  M5: 300,
  M15: 900,
  H1: 3600,
  H4: 14400,
};

export type SignalSide = "BUY" | "SELL" | "WAIT";
export type StructureBias = "uptrend" | "downtrend" | "range";
export type SwingKind = "HH" | "HL" | "LH" | "LL" | "EH" | "EL";
export type SessionName = "Asia" | "London" | "New York" | "Overlap" | "Off";

export interface Candle {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Quote {
  last: number;
  bid: number;
  ask: number;
  spread: number;
  changeAbs: number;
  changePct: number;
  dayHigh: number;
  dayLow: number;
  ts: number;
}

export interface IndicatorSnapshot {
  ema9: number | null;
  ema21: number | null;
  ema50: number | null;
  ema200: number | null;
  rsi: number | null;
  atr: number | null;
  atrPct: number | null;
  ema9Series: Array<number | null>;
  ema21Series: Array<number | null>;
  ema50Series: Array<number | null>;
  ema200Series: Array<number | null>;
  rsiSeries: Array<number | null>;
}

export interface SwingPoint {
  time: number;
  price: number;
  type: "high" | "low";
  label: SwingKind;
  index: number;
}

export interface SrLevel {
  price: number;
  kind: "support" | "resistance";
  strength: number;
  source: "swing" | "round";
  distanceAbs: number;
  distanceAtr: number | null;
}

export interface TradePlan {
  side: Exclude<SignalSide, "WAIT">;
  style: "market" | "limit";
  entry: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  riskReward1: number;
  riskReward2: number;
  riskAbs: number;
}

export interface ManagementRec {
  id: string;
  title: string;
  detail: string;
  urgency: "now" | "soon" | "watch";
}

export interface TimeframeVote {
  timeframe: Timeframe;
  side: SignalSide;
  score: number;
  confidence: number;
  note: string;
}

export interface PaperTrade {
  id: string;
  side: "BUY" | "SELL";
  entry: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  openedAt: number;
  timeframe: Timeframe;
  status: "open" | "breakeven";
}

export interface Analysis {
  symbol: "XAUUSD";
  timeframe: Timeframe;
  asOf: number;
  price: number;
  session: SessionName;
  signal: SignalSide;
  confidence: number;
  rationale: string[];
  deskNote: string;
  plan: TradePlan | null;
  indicators: IndicatorSnapshot;
  structure: {
    bias: StructureBias;
    swings: SwingPoint[];
    summary: string;
    lastSwingHigh: number | null;
    lastSwingLow: number | null;
  };
  levels: SrLevel[];
  mtf: TimeframeVote[];
  mtfAlignment: number;
  management: ManagementRec[];
}

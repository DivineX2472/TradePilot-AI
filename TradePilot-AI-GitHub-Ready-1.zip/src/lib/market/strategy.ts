import { snapshotIndicators } from "./indicators";
import { isLateFriday, sessionAt } from "./session";
import { classifyStructure, deriveLevels, findSwings } from "./structure";
import { formatPrice } from "./format";
import { TIMEFRAMES, type Analysis, type Candle, type ManagementRec, type PaperTrade, type SignalSide, type Timeframe, type TimeframeVote, type TradePlan } from "./types";

const WEIGHT: Record<Timeframe, number> = { H4: 4, H1: 3, M15: 2, M5: 1 };

function emaStackScore(ema9: number | null, ema21: number | null, ema50: number | null, ema200: number | null, price: number) {
  if (ema9 == null || ema21 == null || ema50 == null) return 0;
  let score = 0;
  if (ema9 > ema21) score += 1;
  else score -= 1;
  if (ema21 > ema50) score += 1;
  else score -= 1;
  if (ema200 != null) {
    if (price > ema200 && ema50 > ema200) score += 1;
    else if (price < ema200 && ema50 < ema200) score -= 1;
  }
  if (price > ema9 && price > ema21) score += 0.5;
  if (price < ema9 && price < ema21) score -= 0.5;
  return score;
}

function rsiScore(rsi: number | null): number {
  if (rsi == null) return 0;
  if (rsi >= 70) return -1.2;
  if (rsi <= 30) return 1.2;
  if (rsi >= 55 && rsi < 70) return 0.6;
  if (rsi <= 45 && rsi > 30) return -0.6;
  return 0;
}

function voteTimeframe(tf: Timeframe, candles: Candle[]): TimeframeVote {
  const last = candles.at(-1);
  if (!last) {
    return { timeframe: tf, side: "WAIT", score: 0, confidence: 0, note: "No data" };
  }
  const ind = snapshotIndicators(candles);
  const swings = findSwings(candles, tf === "M5" ? 4 : 3);
  const structure = classifyStructure(swings);
  let score = emaStackScore(ind.ema9, ind.ema21, ind.ema50, ind.ema200, last.close);
  if (structure.bias === "uptrend") score += 1.4;
  if (structure.bias === "downtrend") score -= 1.4;
  score += rsiScore(ind.rsi);

  const nearestRes = deriveLevels(candles, swings, ind.atr).find((l) => l.kind === "resistance");
  const nearestSup = deriveLevels(candles, swings, ind.atr).find((l) => l.kind === "support");
  if (nearestRes && nearestRes.distanceAbs < (ind.atr ?? 4) * 0.35) score -= 0.5;
  if (nearestSup && nearestSup.distanceAbs < (ind.atr ?? 4) * 0.35) score += 0.5;

  let side: SignalSide = "WAIT";
  if (score >= 2.2) side = "BUY";
  else if (score <= -2.2) side = "SELL";

  const confidence = Math.max(8, Math.min(92, Math.round(36 + Math.abs(score) * 12)));
  const note =
    side === "WAIT"
      ? `${tf} mixed — ${structure.bias}`
      : `${tf} ${side === "BUY" ? "bullish" : "bearish"} · ${structure.bias}`;

  return { timeframe: tf, side, score, confidence, note };
}

function buildPlan(
  side: Exclude<SignalSide, "WAIT">,
  price: number,
  candles: Candle[],
  atrValue: number | null,
  lastSwingHigh: number | null,
  lastSwingLow: number | null,
  ema21: number | null,
): TradePlan {
  const atr = atrValue ?? price * 0.0018;
  const stretched =
    ema21 != null ? Math.abs(price - ema21) > atr * 0.9 : false;
  let entry = price;
  let style: TradePlan["style"] = "market";
  if (stretched && ema21 != null) {
    entry = +ema21.toFixed(2);
    style = "limit";
  }

  let stopLoss: number;
  if (side === "BUY") {
    const structureStop = lastSwingLow != null ? lastSwingLow - atr * 0.15 : entry - atr * 1.5;
    stopLoss = Math.min(structureStop, entry - atr * 1.05);
  } else {
    const structureStop = lastSwingHigh != null ? lastSwingHigh + atr * 0.15 : entry + atr * 1.5;
    stopLoss = Math.max(structureStop, entry + atr * 1.05);
  }
  stopLoss = +stopLoss.toFixed(2);
  const riskAbs = Math.abs(entry - stopLoss);
  const dir = side === "BUY" ? 1 : -1;
  const takeProfit1 = +(entry + dir * riskAbs * 1.6).toFixed(2);
  const takeProfit2 = +(entry + dir * riskAbs * 2.8).toFixed(2);
  return {
    side,
    style,
    entry: +entry.toFixed(2),
    stopLoss,
    takeProfit1,
    takeProfit2,
    riskReward1: 1.6,
    riskReward2: 2.8,
    riskAbs: +riskAbs.toFixed(2),
  };
}

function buildDeskNote(analysis: {
  signal: SignalSide;
  timeframe: Timeframe;
  price: number;
  structureBias: string;
  mtf: TimeframeVote[];
  nearest: { support?: number; resistance?: number };
  rsi: number | null;
}): string {
  const px = formatPrice(analysis.price);
  const h4 = analysis.mtf.find((v) => v.timeframe === "H4");
  const h1 = analysis.mtf.find((v) => v.timeframe === "H1");
  const map = `${h4?.side ?? "WAIT"} H4 / ${h1?.side ?? "WAIT"} H1`;
  if (analysis.signal === "WAIT") {
    return `XAUUSD at ${px} is not a clean ${analysis.timeframe} release. Higher-timeframe map is ${map}, structure is ${analysis.structureBias}. Stay flat until H1 and H4 agree and price gives a pullback rather than a chase.`;
  }
  const band =
    analysis.signal === "BUY"
      ? analysis.nearest.support
        ? `holding ${formatPrice(analysis.nearest.support)}`
        : "buying dips"
      : analysis.nearest.resistance
        ? `capped by ${formatPrice(analysis.nearest.resistance)}`
        : "selling rallies";
  const rsiBit = analysis.rsi != null ? ` RSI ${analysis.rsi.toFixed(0)}.` : ".";
  return `Desk bias is ${analysis.signal} on the ${analysis.timeframe} with ${map}. Price ${px} is ${band}.${rsiBit} Treat it as a planned setup — no orders are sent from this board.`;
}

export function recommendManagement(
  price: number,
  plan: TradePlan | null,
  paper: PaperTrade | null,
  atr: number | null,
): ManagementRec[] {
  const recs: ManagementRec[] = [];
  const working = paper
    ? {
        side: paper.side,
        entry: paper.entry,
        stopLoss: paper.stopLoss,
        takeProfit1: paper.takeProfit1,
        takeProfit2: paper.takeProfit2,
        status: paper.status,
      }
    : plan
      ? {
          side: plan.side,
          entry: plan.entry,
          stopLoss: plan.stopLoss,
          takeProfit1: plan.takeProfit1,
          takeProfit2: plan.takeProfit2,
          status: "open" as const,
        }
      : null;

  if (!working) {
    return [
      {
        id: "flat",
        title: "Stay flat",
        detail: "No actionable plan. Wait for H1/H4 alignment before arming an entry.",
        urgency: "watch",
      },
      {
        id: "gap",
        title: "Protect the weekend",
        detail: "If it is late Friday, do not open a fresh XAUUSD swing into the close.",
        urgency: "watch",
      },
      {
        id: "trigger",
        title: "Trigger conditions",
        detail: "Need stacked EMAs, a HL/LH in structure, and RSI out of the extreme before risking a ticket.",
        urgency: "watch",
      },
    ];
  }

  const dir = working.side === "BUY" ? 1 : -1;
  const risk = Math.abs(working.entry - working.stopLoss) || 1;
  const rMultiple = ((price - working.entry) * dir) / risk;
  const atrVal = atr ?? risk;

  if (rMultiple >= 1 || working.status === "breakeven") {
    recs.push({
      id: "be",
      title: "Move stop to breakeven",
      detail: `Price is ${rMultiple.toFixed(2)}R from entry. Stop belongs at ${formatPrice(working.entry)} (plus spread) to kill reverse risk.`,
      urgency: "now",
    });
  } else {
    recs.push({
      id: "be",
      title: "Breakeven rule",
      detail: `Leave the original stop until +1R ($${formatPrice(working.entry + dir * risk)}). Do not tighten through noise.`,
      urgency: "watch",
    });
  }

  if (rMultiple >= 1.5) {
    recs.push({
      id: "trail",
      title: "Trail the stop",
      detail: `Lock ${Math.max(0.4, rMultiple - 1).toFixed(1)}R. Trail ${working.side === "BUY" ? "under" : "above"} the last swing by 0.3×ATR (${formatPrice(atrVal * 0.3)}).`,
      urgency: "now",
    });
  } else {
    recs.push({
      id: "trail",
      title: "Trailing plan",
      detail: `After TP1, trail with 1.2×ATR (${formatPrice(atrVal * 1.2)}) or last confirmed swing. Never trail tighter than structure.`,
      urgency: "soon",
    });
  }

  const throughTp1 = dir === 1 ? price >= working.takeProfit1 : price <= working.takeProfit1;
  if (throughTp1) {
    recs.push({
      id: "close",
      title: "Scale out at TP1",
      detail: `Bank half at ${formatPrice(working.takeProfit1)}. Runner targets ${formatPrice(working.takeProfit2)}; close the rest if H1 structure breaks.`,
      urgency: "now",
    });
  } else if (rMultiple <= -0.85) {
    recs.push({
      id: "close",
      title: "Respect the stop",
      detail: "Do not widen the stop. If the idea is wrong, the close is the original SL — not hope.",
      urgency: "now",
    });
  } else {
    recs.push({
      id: "close",
      title: "Hard close",
      detail: `Close the book on a H1 close ${working.side === "BUY" ? "below" : "above"} EMA 21 and a break of the last swing. TP2 remains ${formatPrice(working.takeProfit2)}.`,
      urgency: "watch",
    });
  }

  return recs;
}

export function analyzeMarket(
  active: Timeframe,
  books: Record<Timeframe, Candle[]>,
  paper: PaperTrade | null,
): Analysis | null {
  const candles = books[active];
  const last = candles?.at(-1);
  if (!last) return null;

  const indicators = snapshotIndicators(candles);
  const swings = findSwings(candles, active === "M5" ? 4 : 3);
  const structure = classifyStructure(swings);
  const levels = deriveLevels(candles, swings, indicators.atr);
  const mtf = TIMEFRAMES.map((tf) => voteTimeframe(tf, books[tf] ?? []));

  const h4 = mtf.find((v) => v.timeframe === "H4")!;
  const h1 = mtf.find((v) => v.timeframe === "H1")!;
  const conflict = h4.side !== "WAIT" && h1.side !== "WAIT" && h4.side !== h1.side;

  let weighted = 0;
  let denom = 0;
  for (const v of mtf) {
    const w = WEIGHT[v.timeframe];
    weighted += v.score * w;
    denom += w;
  }
  let combo = weighted / denom;
  if (conflict) combo *= 0.25;

  const nowSec = last.time;
  if (isLateFriday(nowSec)) combo *= 0.72;

  let signal: SignalSide = "WAIT";
  if (!conflict && combo >= 1.35) signal = "BUY";
  else if (!conflict && combo <= -1.35) signal = "SELL";
  if (h4.side === "WAIT" && h1.side === "WAIT") signal = "WAIT";

  const aligned = mtf.filter((v) => v.side === signal && signal !== "WAIT").length;
  const confidence = Math.max(
    10,
    Math.min(
      90,
      Math.round(28 + Math.abs(combo) * 18 + aligned * 6 - (conflict ? 18 : 0) - (isLateFriday(nowSec) ? 10 : 0)),
    ),
  );

  const rationale: string[] = [];
  if (conflict) rationale.push("H4 and H1 disagree — confluence veto, sit on hands.");
  else rationale.push(`Higher-timeframe map: H4 ${h4.side}, H1 ${h1.side}.`);

  if (indicators.ema9 != null && indicators.ema21 != null && indicators.ema50 != null) {
    const stacked =
      indicators.ema9 > indicators.ema21 && indicators.ema21 > indicators.ema50
        ? "bullish"
        : indicators.ema9 < indicators.ema21 && indicators.ema21 < indicators.ema50
          ? "bearish"
          : "compressed";
    rationale.push(
      `${active} EMA 9/21/50 is ${stacked} (${formatPrice(indicators.ema9)} / ${formatPrice(indicators.ema21)} / ${formatPrice(indicators.ema50)}).`,
    );
  }
  if (indicators.rsi != null) {
    rationale.push(
      `RSI 14 at ${indicators.rsi.toFixed(1)}${indicators.rsi > 68 ? " — stretched long" : indicators.rsi < 32 ? " — stretched short" : " — room to work"}.`,
    );
  }
  if (indicators.atr != null) {
    rationale.push(`ATR 14 is ${formatPrice(indicators.atr)} (${indicators.atrPct?.toFixed(2)}% of spot). Size off this, not hope.`);
  }
  rationale.push(structure.summary);
  if (isLateFriday(nowSec)) rationale.push("Late Friday session — weekend gap risk. Prefer WAIT or tiny size.");

  const plan =
    signal === "WAIT"
      ? null
      : buildPlan(
          signal,
          last.close,
          candles,
          indicators.atr,
          structure.lastSwingHigh,
          structure.lastSwingLow,
          indicators.ema21,
        );

  const nearestSup = levels.find((l) => l.kind === "support")?.price;
  const nearestRes = levels.find((l) => l.kind === "resistance")?.price;

  const partial = {
    signal,
    timeframe: active,
    price: last.close,
    structureBias: structure.bias,
    mtf,
    nearest: { support: nearestSup, resistance: nearestRes },
    rsi: indicators.rsi,
  };

  return {
    symbol: "XAUUSD",
    timeframe: active,
    asOf: last.time * 1000,
    price: last.close,
    session: sessionAt(last.time),
    signal,
    confidence,
    rationale,
    deskNote: buildDeskNote(partial),
    plan,
    indicators,
    structure: { ...structure, swings: swings.slice(-12) },
    levels,
    mtf,
    mtfAlignment: aligned,
    management: recommendManagement(last.close, plan, paper, indicators.atr),
  };
}

export function positionSize(account: number, riskPct: number, riskAbs: number) {
  const riskCash = account * (riskPct / 100);
  const perLot = riskAbs * 100;
  const lots = perLot <= 0 ? 0 : riskCash / perLot;
  return {
    riskCash,
    lots: Math.max(0, lots),
  };
}

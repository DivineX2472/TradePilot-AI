import { TIMEFRAME_SECONDS, type Candle, type Timeframe } from "./types";

export function aggregateFromM5(m5: Candle[], tf: Timeframe): Candle[] {
  const seconds = TIMEFRAME_SECONDS[tf];
  if (tf === "M5") return m5;
  const buckets: Candle[] = [];
  let current: Candle | null = null;
  for (const c of m5) {
    const t = Math.floor(c.time / seconds) * seconds;
    if (!current || current.time !== t) {
      if (current) buckets.push(current);
      current = {
        time: t,
        open: c.open,
        high: c.high,
        low: c.low,
        close: c.close,
        volume: c.volume,
      };
    } else {
      current.high = Math.max(current.high, c.high);
      current.low = Math.min(current.low, c.low);
      current.close = c.close;
      current.volume += c.volume;
    }
  }
  if (current) buckets.push(current);
  return buckets;
}

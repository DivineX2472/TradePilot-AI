import type { Candle, Timeframe } from "./types";

/** Thrown by adapters that are wired in the UI but not connected yet. */
export class AdapterNotConnectedError extends Error {
  constructor(adapterId: string) {
    super(`${adapterId} is not connected in this build.`);
    this.name = "AdapterNotConnectedError";
  }
}

export type AdapterStatus = "live" | "ready";

export interface MarketAdapterInfo {
  id: "demo" | "mt5" | "grok" | "news";
  label: string;
  status: AdapterStatus;
  blurb: string;
  detail: string;
}

export interface MarketDataAdapter {
  id: string;
  getCandles(symbol: string, tf: Timeframe): Promise<Candle[]>;
  subscribe?(symbol: string, tf: Timeframe, onTick: () => void): () => void;
}

export interface AiAnalystAdapter {
  id: "grok";
  analyze(prompt: string): Promise<string>;
}

export interface NewsAdapter {
  id: "news";
  headlines(symbol: string): Promise<Array<{ title: string; at: number; impact: "high" | "med" | "low" }>>;
}

export const ADAPTERS: MarketAdapterInfo[] = [
  {
    id: "demo",
    label: "Demo tape",
    status: "live",
    blurb: "Realistic XAUUSD simulation",
    detail: "On. Path, session volatility and weekend gaps are modelled so the desk can be used without a broker.",
  },
  {
    id: "mt5",
    label: "MetaTrader 5",
    status: "ready",
    blurb: "Live bid/ask and chart sync",
    detail: "Adapter contract is in place. Quotes and history can stream in; order execution stays disabled until you turn it on.",
  },
  {
    id: "grok",
    label: "Grok analyst",
    status: "ready",
    blurb: "Narrative overlay",
    detail: "Will annotate the rules engine on demand. No model calls run until you connect it — the desk note today is the local playbook.",
  },
  {
    id: "news",
    label: "Macro calendar",
    status: "ready",
    blurb: "Gold event risk",
    detail: "FOMC, CPI, NFP and USD prints will flag WAIT windows. Not live in this build.",
  },
];

export const STRATEGIES = [
  {
    id: "ema-structure",
    name: "EMA + structure confluence",
    status: "live" as const,
    blurb: "9/21/50/200 stack, RSI, ATR stops, swing S/R, multi-timeframe veto.",
  },
  {
    id: "smc",
    name: "Liquidity / SMC",
    status: "ready" as const,
    blurb: "Equal highs, sweeps and continuation — slot ready, not scoring yet.",
  },
  {
    id: "news-impulse",
    name: "News impulse",
    status: "ready" as const,
    blurb: "Fade or follow the first impulse after a scheduled USD release.",
  },
];

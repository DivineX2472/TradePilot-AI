import type { SessionName } from "./types";

/** Gold roughly trades Sun 22:00–Fri 21:00 UTC. */
export function isMarketOpen(unixSec: number): boolean {
  const d = new Date(unixSec * 1000);
  const day = d.getUTCDay();
  const minutes = d.getUTCHours() * 60 + d.getUTCMinutes();
  if (day === 6) return false;
  if (day === 0 && minutes < 22 * 60) return false;
  if (day === 5 && minutes >= 21 * 60) return false;
  return true;
}

export function sessionAt(unixSec: number): SessionName {
  if (!isMarketOpen(unixSec)) return "Off";
  const h = new Date(unixSec * 1000).getUTCHours();
  if (h >= 12 && h < 16) return "Overlap";
  if (h >= 12 && h < 21) return "New York";
  if (h >= 7 && h < 16) return "London";
  return "Asia";
}

export function sessionVolatility(unixSec: number): number {
  const session = sessionAt(unixSec);
  switch (session) {
    case "Overlap":
      return 2.6;
    case "New York":
      return 2.2;
    case "London":
      return 2.0;
    case "Asia":
      return 1.15;
    default:
      return 0.8;
  }
}

export function isLateFriday(unixSec: number): boolean {
  const d = new Date(unixSec * 1000);
  return d.getUTCDay() === 5 && d.getUTCHours() >= 18;
}

import { aggregateFromM5 } from "./aggregate";
import { isMarketOpen, sessionVolatility } from "./session";
import type { Candle, Quote, Timeframe } from "./types";

const M5 = 300;
const BAR_COUNT = 14000;
const ANCHOR = 4146.28;

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function gauss(rng: () => number) {
  let u = 0;
  let v = 0;
  while (u === 0) u = rng();
  while (v === 0) v = rng();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

function previousSlot(timeSec: number): number {
  let t = timeSec - M5;
  while (!isMarketOpen(t)) t -= M5;
  return t;
}

function buildTimes(nowSec: number, count: number): number[] {
  const times: number[] = [];
  let t = Math.floor(nowSec / M5) * M5;
  if (!isMarketOpen(t)) t = previousSlot(t + M5);
  while (times.length < count) {
    if (isMarketOpen(t)) times.push(t);
    t -= M5;
  }
  times.reverse();
  return times;
}

function synthesizeM5(nowSec: number): Candle[] {
  const day = Math.floor(nowSec / 86400);
  const rng = mulberry32(414628 + day);
  const times = buildTimes(nowSec, BAR_COUNT);
  const start = 4478;
  const candles: Candle[] = [];
  let price = start;

  for (let i = 0; i < times.length; i++) {
    const t = times[i]!;
    const progress = i / (times.length - 1);
    const fair = start + (ANCHOR - start) * progress;
    const cycle = Math.sin(i / 90) * 14 + Math.sin(i / 240) * 22;
    const target = fair + cycle;
    const vol = sessionVolatility(t);
    const shock = rng() < 0.0028 ? gauss(rng) * vol * 7 : 0;
    const magnet = (Math.round(price / 25) * 25 - price) * 0.02;
    const ret = (target - price) * 0.05 + gauss(rng) * vol * 0.42 + shock + magnet;
    const open = price;
    const close = Math.max(3800, open + ret);
    const wickUp = Math.abs(gauss(rng)) * vol * 0.45;
    const wickDown = Math.abs(gauss(rng)) * vol * 0.45;
    const high = Math.max(open, close) + wickUp;
    const low = Math.min(open, close) - wickDown;
    const hour = new Date(t * 1000).getUTCHours();
    const volBase = hour >= 7 && hour < 17 ? 820 : 340;
    candles.push({
      time: t,
      open: +open.toFixed(2),
      high: +high.toFixed(2),
      low: +low.toFixed(2),
      close: +close.toFixed(2),
      volume: Math.round(volBase * (0.6 + rng())),
    });
    price = close;
  }

  const last = candles[candles.length - 1];
  if (last) {
    const drift = ANCHOR - last.close;
    last.close = +(last.close + drift).toFixed(2);
    last.high = +Math.max(last.high, last.close, last.open).toFixed(2);
    last.low = +Math.min(last.low, last.close, last.open).toFixed(2);
  }
  return candles;
}

function dayRange(m5: Candle[], nowSec: number) {
  const start = Math.floor(nowSec / 86400) * 86400;
  const todays = m5.filter((c) => c.time >= start);
  const sample = todays.length ? todays : m5.slice(-80);
  let high = -Infinity;
  let low = Infinity;
  for (const c of sample) {
    high = Math.max(high, c.high);
    low = Math.min(low, c.low);
  }
  return { high, low };
}

export class DemoFeed {
  private m5: Candle[];
  private version = 1;
  private listeners = new Set<() => void>();
  private timer: ReturnType<typeof setInterval> | null = null;
  private spread = 0.32;

  constructor(nowSec = Math.floor(Date.now() / 1000)) {
    this.m5 = synthesizeM5(nowSec);
  }

  getVersion() {
    return this.version;
  }

  getCandles(tf: Timeframe): Candle[] {
    return aggregateFromM5(this.m5, tf);
  }

  quote(): Quote {
    const lastBar = this.m5[this.m5.length - 1]!;
    const last = lastBar.close;
    const openDay = this.sessionOpen();
    const { high, low } = dayRange(this.m5, lastBar.time);
    const half = this.spread / 2;
    return {
      last,
      bid: +(last - half).toFixed(2),
      ask: +(last + half).toFixed(2),
      spread: this.spread,
      changeAbs: +(last - openDay).toFixed(2),
      changePct: +(((last - openDay) / openDay) * 100).toFixed(2),
      dayHigh: high,
      dayLow: low,
      ts: lastBar.time * 1000,
    };
  }

  subscribe(cb: () => void) {
    this.listeners.add(cb);
    if (this.listeners.size === 1) this.start();
    return () => {
      this.listeners.delete(cb);
      if (this.listeners.size === 0) this.stop();
    };
  }

  private sessionOpen(): number {
    const last = this.m5[this.m5.length - 1]!;
    const dayStart = Math.floor(last.time / 86400) * 86400;
    const first = this.m5.find((c) => c.time >= dayStart);
    return first?.open ?? last.open;
  }

  private start() {
    this.timer = setInterval(() => this.tick(), 1100);
  }

  private stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  private tick() {
    if (typeof document !== "undefined" && document.hidden) return;
    const nowSec = Math.floor(Date.now() / 1000);
    const bucket = Math.floor(nowSec / M5) * M5;
    let last = this.m5[this.m5.length - 1]!;
    if (isMarketOpen(bucket) && bucket > last.time) {
      const open = last.close;
      last = {
        time: bucket,
        open,
        high: open,
        low: open,
        close: open,
        volume: 120,
      };
      this.m5.push(last);
      if (this.m5.length > BAR_COUNT + 50) this.m5.shift();
    }
    const vol = sessionVolatility(last.time);
    const step = gauss(Math.random) * vol * 0.12;
    const close = +(last.close + step).toFixed(2);
    last.close = close;
    last.high = +Math.max(last.high, close).toFixed(2);
    last.low = +Math.min(last.low, close).toFixed(2);
    last.volume += Math.round(8 + Math.random() * 18);
    this.spread = +(0.26 + Math.random() * 0.12).toFixed(2);
    this.version += 1;
    for (const cb of this.listeners) cb();
  }
}

let feed: DemoFeed | null = null;

export function getDemoFeed(): DemoFeed | null {
  if (typeof window === "undefined") return null;
  if (!feed) feed = new DemoFeed();
  return feed;
}

export function subscribeFeed(cb: () => void) {
  const f = getDemoFeed();
  if (!f) return () => {};
  return f.subscribe(cb);
}

export function getFeedVersion() {
  return getDemoFeed()?.getVersion() ?? 0;
}

export function getServerFeedVersion() {
  return 0;
}

import type { SignalSide, Timeframe } from "./types";

export function formatPrice(n: number, digits = 2): string {
  return n.toLocaleString("en-US", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  });
}

export function formatSigned(n: number, digits = 2): string {
  const abs = formatPrice(Math.abs(n), digits);
  if (n > 0) return `+${abs}`;
  if (n < 0) return `−${abs}`;
  return abs;
}

export function formatPct(n: number, digits = 2): string {
  const body = Math.abs(n).toFixed(digits);
  if (n > 0) return `+${body}%`;
  if (n < 0) return `−${body}%`;
  return `${body}%`;
}

export function formatRr(n: number): string {
  return `${n.toFixed(2)}R`;
}

export function sideLabel(side: SignalSide): string {
  if (side === "BUY") return "Buy";
  if (side === "SELL") return "Sell";
  return "Wait";
}

export function tfLabel(tf: Timeframe): string {
  return tf;
}

export function utcStamp(ms: number): string {
  return new Date(ms).toLocaleString("en-GB", {
    timeZone: "UTC",
    hour12: false,
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

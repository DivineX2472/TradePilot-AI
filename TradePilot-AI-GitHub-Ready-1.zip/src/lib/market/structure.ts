import type { Candle, SrLevel, StructureBias, SwingKind, SwingPoint } from "./types";

export function findSwings(candles: Candle[], radius = 3): SwingPoint[] {
  const raw: Array<Omit<SwingPoint, "label">> = [];
  for (let i = radius; i < candles.length - radius; i++) {
    const c = candles[i]!;
    let isHigh = true;
    let isLow = true;
    for (let j = i - radius; j <= i + radius; j++) {
      if (j === i) continue;
      if (candles[j]!.high >= c.high) isHigh = false;
      if (candles[j]!.low <= c.low) isLow = false;
    }
    if (isHigh) raw.push({ time: c.time, price: c.high, type: "high", index: i });
    else if (isLow) raw.push({ time: c.time, price: c.low, type: "low", index: i });
  }

  const labeled: SwingPoint[] = [];
  let lastHigh: number | null = null;
  let lastLow: number | null = null;
  for (const s of raw) {
    let label: SwingKind;
    if (s.type === "high") {
      if (lastHigh == null) label = "EH";
      else if (s.price > lastHigh * 1.00015) label = "HH";
      else if (s.price < lastHigh * 0.99985) label = "LH";
      else label = "EH";
      lastHigh = s.price;
    } else {
      if (lastLow == null) label = "EL";
      else if (s.price < lastLow * 0.99985) label = "LL";
      else if (s.price > lastLow * 1.00015) label = "HL";
      else label = "EL";
      lastLow = s.price;
    }
    labeled.push({ ...s, label });
  }
  return labeled;
}

export function classifyStructure(swings: SwingPoint[]): {
  bias: StructureBias;
  summary: string;
  lastSwingHigh: number | null;
  lastSwingLow: number | null;
} {
  const highs = swings.filter((s) => s.type === "high");
  const lows = swings.filter((s) => s.type === "low");
  const lastHighs = highs.slice(-2);
  const lastLows = lows.slice(-2);
  const lastSwingHigh = highs.at(-1)?.price ?? null;
  const lastSwingLow = lows.at(-1)?.price ?? null;

  const risingHighs = lastHighs.length === 2 && lastHighs[1]!.price > lastHighs[0]!.price;
  const fallingHighs = lastHighs.length === 2 && lastHighs[1]!.price < lastHighs[0]!.price;
  const risingLows = lastLows.length === 2 && lastLows[1]!.price > lastLows[0]!.price;
  const fallingLows = lastLows.length === 2 && lastLows[1]!.price < lastLows[0]!.price;

  if (risingHighs && risingLows) {
    return {
      bias: "uptrend",
      summary: "Market structure is bullish: higher highs and higher lows are intact.",
      lastSwingHigh,
      lastSwingLow,
    };
  }
  if (fallingHighs && fallingLows) {
    return {
      bias: "downtrend",
      summary: "Market structure is bearish: lower highs and lower lows are intact.",
      lastSwingHigh,
      lastSwingLow,
    };
  }
  return {
    bias: "range",
    summary: "Structure is mixed — no clean HH/HL or LH/LL sequence on the last swings.",
    lastSwingHigh,
    lastSwingLow,
  };
}

export function deriveLevels(
  candles: Candle[],
  swings: SwingPoint[],
  atrValue: number | null,
): SrLevel[] {
  const price = candles.at(-1)?.close;
  if (price == null) return [];

  const clusterTol = Math.max(price * 0.0007, atrValue ? atrValue * 0.35 : 2);
  type Cluster = { price: number; count: number; source: "swing" | "round" };
  const clusters: Cluster[] = [];

  const add = (p: number, source: "swing" | "round") => {
    const hit = clusters.find((c) => Math.abs(c.price - p) <= clusterTol);
    if (hit) {
      hit.price = (hit.price * hit.count + p) / (hit.count + 1);
      hit.count += 1;
      if (source === "swing") hit.source = "swing";
    } else {
      clusters.push({ price: p, count: 1, source });
    }
  };

  for (const s of swings.slice(-40)) add(s.price, "swing");

  const roundStep = 25;
  const base = Math.round(price / roundStep) * roundStep;
  for (const offset of [-75, -50, -25, 0, 25, 50, 75]) {
    add(base + offset, "round");
  }

  const levels: SrLevel[] = clusters
    .map((c) => {
      const kind: SrLevel["kind"] = c.price >= price ? "resistance" : "support";
      const distanceAbs = Math.abs(c.price - price);
      return {
        price: c.price,
        kind,
        strength: Math.min(5, c.count + (c.source === "round" ? 1 : 0)),
        source: c.source,
        distanceAbs,
        distanceAtr: atrValue ? distanceAbs / atrValue : null,
      };
    })
    .sort((a, b) => a.distanceAbs - b.distanceAbs);

  const supports = levels.filter((l) => l.kind === "support").slice(0, 3);
  const resistances = levels.filter((l) => l.kind === "resistance").slice(0, 3);
  return [...supports, ...resistances].sort((a, b) => b.price - a.price);
}

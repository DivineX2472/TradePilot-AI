/** Chart/canvas colors — keep in lockstep with `src/styles.css` `@theme`. */
export const palette = {
  bg: "#08090b",
  surface: "#101215",
  elevated: "#161a1f",
  fg: "#eceef1",
  muted: "#8b939e",
  subtle: "#5c6570",
  border: "#1c2128",
  grid: "#14181d",
  primary: "#d7dde6",
  bull: "#3dba8b",
  bear: "#e05d56",
  caution: "#d3b277",
  ema9: "#e8edf3",
  ema21: "#8aa0b8",
  ema50: "#6b7c8f",
  ema200: "#3d4754",
} as const;

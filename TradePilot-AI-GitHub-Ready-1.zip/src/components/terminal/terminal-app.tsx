import { useEffect } from "react";
import { Toaster } from "sonner";
import { ChartPanel } from "@/components/terminal/chart-panel";
import { AnalysisCards } from "@/components/terminal/analysis-cards";
import { IntegrationsSheet } from "@/components/terminal/integrations-sheet";
import { QuoteChange, SignalPanel } from "@/components/terminal/signal-panel";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useMarket } from "@/hooks/use-market";
import { TIMEFRAMES, formatPrice, utcStamp } from "@/lib/market";
import { useTerminal } from "@/stores/terminal";
import { cn } from "@/lib/utils";

export function TerminalApp() {
  const timeframe = useTerminal((s) => s.timeframe);
  const paper = useTerminal((s) => s.paper);
  const setTimeframe = useTerminal((s) => s.setTimeframe);
  const { ready, candles, quote, analysis } = useMarket(timeframe, paper);

  useEffect(() => {
    void useTerminal.persist.rehydrate();
  }, []);

  const signalVariant =
    analysis?.signal === "BUY" ? "bull" : analysis?.signal === "SELL" ? "bear" : "caution";

  return (
    <div className="flex min-h-dvh flex-col bg-background text-foreground pb-[env(safe-area-inset-bottom)]">
      <Toaster theme="dark" position="bottom-right" richColors={false} />
      <header className="sticky top-0 z-20 border-b border-border bg-background/92 backdrop-blur-sm">
        <div className="flex flex-col gap-3 px-4 py-3 lg:px-6">
          <div className="flex items-center gap-3">
            <div className="flex min-w-0 items-center gap-2.5">
              <Mark />
              <div className="min-w-0">
                <p className="text-sm font-medium tracking-tight">TradePilot</p>
                <p className="text-xs tracking-[0.18em] text-muted-foreground uppercase">AI desk</p>
              </div>
            </div>

            <div className="ml-auto flex items-center gap-2 sm:ml-4 sm:flex-1 sm:justify-center">
              {quote ? (
                <div className="flex min-w-0 flex-wrap items-baseline justify-end gap-x-3 gap-y-0.5 sm:justify-center">
                  <h1 className="text-sm font-medium tracking-tight">XAUUSD</h1>
                  <span className="hidden text-xs text-muted-foreground sm:inline">Gold spot</span>
                  <span className="font-mono text-lg font-medium tabular-nums">{formatPrice(quote.last)}</span>
                  <QuoteChange abs={quote.changeAbs} pct={quote.changePct} />
                </div>
              ) : (
                <span className="h-6 w-40 animate-pulse rounded-md bg-secondary" />
              )}
            </div>

            <div className="hidden items-center gap-2 sm:flex">
              {analysis ? <Badge variant={signalVariant}>{analysis.signal}</Badge> : null}
              {quote ? (
                <span className="inline-flex items-center gap-2 rounded-full bg-secondary px-3 py-1.5 text-xs text-muted-foreground">
                  <span className="live-dot" />
                  Demo
                </span>
              ) : null}
              <IntegrationsSheet />
            </div>
            <div className="sm:hidden">
              <IntegrationsSheet />
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-2 lg:px-6">
          <div className="flex rounded-lg bg-secondary p-1">
            {TIMEFRAMES.map((tf) => (
              <Button
                key={tf}
                variant="ghost"
                size="sm"
                onClick={() => setTimeframe(tf)}
                className={cn(
                  "h-9 min-w-11 px-3.5 text-xs",
                  timeframe === tf && "bg-primary text-primary-foreground hover:bg-primary/90 hover:text-primary-foreground",
                )}
              >
                {tf}
              </Button>
            ))}
          </div>
          <div className="flex items-center gap-2">
            {analysis ? (
              <Badge variant={signalVariant} className="sm:hidden">
                {analysis.signal}
              </Badge>
            ) : null}
            <p className="text-xs text-muted-foreground">
              Analysis only · demo tape
              {analysis ? (
                <span className="ml-2 hidden font-mono tabular-nums md:inline">
                  {analysis.session} · {utcStamp(analysis.asOf)} UTC
                </span>
              ) : null}
            </p>
          </div>
        </div>
      </header>

      <main className="grid flex-1 gap-3 p-3 lg:p-4 xl:grid-cols-[minmax(0,1fr)_22rem] xl:items-start">
        <div className="flex min-w-0 flex-col gap-3">
          {ready && analysis ? (
            <>
              <ChartPanel candles={candles} analysis={analysis} plan={analysis.plan} />
              <AnalysisCards analysis={analysis} />
              <WhyCard bullets={analysis.rationale} />
            </>
          ) : (
            <LoadingDesk />
          )}
        </div>
        {ready && analysis ? (
          <div className="order-first xl:order-none">
            <SignalPanel analysis={analysis} />
          </div>
        ) : (
          <aside className="order-first h-96 animate-pulse rounded-xl bg-card xl:order-none" />
        )}
      </main>
    </div>
  );
}

function Mark() {
  return (
    <svg viewBox="0 0 24 24" className="size-8 shrink-0 text-foreground" aria-hidden="true">
      <rect x="3.5" y="3.5" width="17" height="17" rx="4" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <rect x="10.5" y="6" width="3" height="12" rx="0.6" fill="currentColor" />
      <rect x="7" y="6" width="10" height="2.4" rx="0.6" fill="currentColor" />
    </svg>
  );
}

function WhyCard({ bullets }: { bullets: string[] }) {
  return (
    <section className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <p className="mb-3 text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">Why this call</p>
      <ul className="flex flex-col gap-2">
        {bullets.map((b) => (
          <li key={b} className="flex gap-2 text-sm leading-relaxed text-muted-foreground">
            <span className="mt-2 size-1 shrink-0 rounded-full bg-primary/70" />
            {b}
          </li>
        ))}
      </ul>
    </section>
  );
}

function LoadingDesk() {
  return (
    <div className="flex flex-col gap-3">
      <div className="h-72 animate-pulse rounded-xl bg-card md:h-chart" />
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-40 animate-pulse rounded-xl bg-card" />
        ))}
      </div>
    </div>
  );
}

import type { ReactNode } from "react";
import { Shield, Target, TrendingDown, TrendingUp, Minus, Crosshair } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Separator } from "@/components/ui/separator";
import { formatPct, formatPrice, formatRr, formatSigned, positionSize, type Analysis } from "@/lib/market";
import { useTerminal } from "@/stores/terminal";
import { cn } from "@/lib/utils";

function signalTone(side: Analysis["signal"]) {
  if (side === "BUY") return "text-bull";
  if (side === "SELL") return "text-bear";
  return "text-caution";
}

function SignalGlyph({ side }: { side: Analysis["signal"] }) {
  if (side === "BUY") return <TrendingUp className="size-5" />;
  if (side === "SELL") return <TrendingDown className="size-5" />;
  return <Minus className="size-5" />;
}

export function SignalPanel({ analysis }: { analysis: Analysis }) {
  const { account, riskPct, paper, setAccount, setRiskPct, trackPlan, flatten, markBreakeven } = useTerminal();
  const plan = analysis.plan;
  const size = plan ? positionSize(account, riskPct, plan.riskAbs) : null;
  const liveR = paper
    ? ((analysis.price - paper.entry) * (paper.side === "BUY" ? 1 : -1)) / Math.abs(paper.entry - paper.stopLoss || 1)
    : null;

  function onTrack() {
    if (!plan) return;
    trackPlan({
      id: `tp-${Date.now()}`,
      side: plan.side,
      entry: plan.entry,
      stopLoss: plan.stopLoss,
      takeProfit1: plan.takeProfit1,
      takeProfit2: plan.takeProfit2,
      openedAt: Date.now(),
      timeframe: analysis.timeframe,
      status: "open",
    });
    toast("Setup tracked", { description: "Paper only — no broker order was sent." });
  }

  return (
    <aside className="flex flex-col gap-3">
      <section className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <div className="flex items-start justify-between gap-3">
          <p className="text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">Desk signal</p>
          <Badge variant={analysis.signal === "BUY" ? "bull" : analysis.signal === "SELL" ? "bear" : "caution"}>
            {analysis.confidence}% confidence
          </Badge>
        </div>
        <div className={cn("mt-3 flex items-center gap-2 text-3xl font-medium tracking-tight", signalTone(analysis.signal))}>
          <SignalGlyph side={analysis.signal} />
          {analysis.signal}
        </div>
        <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-secondary">
          <div
            className={cn(
              "h-full rounded-full transition-[width] duration-[var(--motion-fast)] ease-[var(--ease-smooth-out)]",
              analysis.signal === "BUY" && "bg-bull",
              analysis.signal === "SELL" && "bg-bear",
              analysis.signal === "WAIT" && "bg-caution",
            )}
            style={{ width: `${analysis.confidence}%` }}
          />
        </div>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">{analysis.deskNote}</p>
      </section>

      <section className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <p className="text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">Trade plan</p>
        {plan ? (
          <>
            <dl className="mt-4 grid grid-cols-2 gap-3">
              <PlanStat label={plan.style === "limit" ? "Limit entry" : "Market entry"} value={formatPrice(plan.entry)} icon={<Crosshair className="size-3.5" />} />
              <PlanStat label="Stop loss" value={formatPrice(plan.stopLoss)} icon={<Shield className="size-3.5" />} tone="bear" />
              <PlanStat label="TP1 · 1.6R" value={formatPrice(plan.takeProfit1)} icon={<Target className="size-3.5" />} tone="bull" />
              <PlanStat label="TP2 · 2.8R" value={formatPrice(plan.takeProfit2)} icon={<Target className="size-3.5" />} tone="bull" />
            </dl>
            <p className="mt-3 font-mono text-xs text-muted-foreground tabular-nums">
              Risk {formatPrice(plan.riskAbs)} · {formatRr(plan.riskReward1)} / {formatRr(plan.riskReward2)}
            </p>
          </>
        ) : (
          <p className="mt-3 text-sm text-muted-foreground">No ticket. The board is in WAIT — do not invent a level.</p>
        )}

        <Separator className="my-4" />

        <div className="grid grid-cols-2 gap-3">
          <label className="flex flex-col gap-1.5 text-xs text-muted-foreground">
            Demo account (USD)
            <Input
              type="number"
              min={100}
              step={100}
              value={account}
              onChange={(e) => setAccount(Number(e.target.value) || 0)}
            />
          </label>
          <label className="flex flex-col gap-1.5 text-xs text-muted-foreground">
            Risk %
            <Input
              type="number"
              min={0.1}
              max={2}
              step={0.1}
              value={riskPct}
              onChange={(e) => setRiskPct(Number(e.target.value) || 0)}
            />
          </label>
        </div>
        {size && plan ? (
          <p className="mt-3 font-mono text-xs text-muted-foreground tabular-nums">
            {formatPrice(size.riskCash, 0)} at risk · {size.lots.toFixed(2)} lots
            <span className="mt-1 block text-xs leading-relaxed">1.00 lot = 100 oz. Advisory size only.</span>
          </p>
        ) : null}

        <div className="mt-4 flex flex-col gap-2">
          {paper ? (
            <>
              <div className="rounded-md bg-secondary px-3 py-2 text-xs">
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium">
                    Tracking {paper.side} from {formatPrice(paper.entry)}
                  </span>
                  <Badge variant={paper.side === "BUY" ? "bull" : "bear"}>{paper.status === "breakeven" ? "BE" : "Open"}</Badge>
                </div>
                <p className="mt-1 font-mono tabular-nums text-muted-foreground">
                  Unrealized {liveR != null ? formatSigned(liveR, 2) : "—"}R · last {formatPrice(analysis.price)}
                </p>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={markBreakeven} disabled={paper.status === "breakeven"}>
                  Move to BE
                </Button>
                <Button variant="secondary" onClick={() => { flatten(); toast("Desk flattened"); }}>
                  Flatten
                </Button>
              </div>
            </>
          ) : (
            <Button onClick={onTrack} disabled={!plan} className="w-full">
              Track this setup
            </Button>
          )}
        </div>
      </section>

      <section className="rounded-xl bg-card p-5 shadow-[var(--shadow-border)]">
        <p className="text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">Trade management</p>
        <ul className="mt-3 flex flex-col gap-3">
          {analysis.management.map((rec) => (
            <li key={rec.id} className="flex gap-3">
              <span
                className={cn(
                  "mt-1 size-2 shrink-0 rounded-full",
                  rec.urgency === "now" && "bg-bear",
                  rec.urgency === "soon" && "bg-caution",
                  rec.urgency === "watch" && "bg-muted-foreground/40",
                )}
              />
              <div>
                <p className="text-sm font-medium">{rec.title}</p>
                <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">{rec.detail}</p>
              </div>
            </li>
          ))}
        </ul>
      </section>
    </aside>
  );
}

function PlanStat({
  label,
  value,
  icon,
  tone,
}: {
  label: string;
  value: string;
  icon: ReactNode;
  tone?: "bull" | "bear";
}) {
  return (
    <div className="rounded-md bg-secondary px-3 py-2.5">
      <dt className="flex items-center gap-1.5 text-xs text-muted-foreground">
        {icon}
        {label}
      </dt>
      <dd
        className={cn(
          "mt-1 font-mono text-sm font-medium tabular-nums",
          tone === "bull" && "text-bull",
          tone === "bear" && "text-bear",
        )}
      >
        {value}
      </dd>
    </div>
  );
}

export function QuoteChange({ abs, pct }: { abs: number; pct: number }) {
  const up = abs >= 0;
  return (
    <span className={cn("font-mono text-sm tabular-nums", up ? "text-bull" : "text-bear")}>
      {formatSigned(abs)} ({formatPct(pct)})
    </span>
  );
}

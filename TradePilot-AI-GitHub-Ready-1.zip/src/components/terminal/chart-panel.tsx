import { useEffect, useRef, useState } from "react";
import {
  CandlestickSeries,
  ColorType,
  CrosshairMode,
  LineSeries,
  LineStyle,
  createChart,
  type CandlestickData,
  type IChartApi,
  type IPriceLine,
  type ISeriesApi,
  type LineData,
  type MouseEventParams,
  type Time,
  type UTCTimestamp,
} from "lightweight-charts";
import { palette } from "@/lib/theme";
import { formatPrice } from "@/lib/market";
import type { Analysis, Candle, TradePlan } from "@/lib/market";
import { cn } from "@/lib/utils";

interface HoverOhlc {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
}

function asTs(time: number): UTCTimestamp {
  return time as UTCTimestamp;
}

function toCandle(c: Candle): CandlestickData<Time> {
  const high = Math.max(c.open, c.high, c.low, c.close);
  const low = Math.min(c.open, c.high, c.low, c.close);
  return { time: asTs(c.time), open: c.open, high, low, close: c.close };
}

function toLine(candles: Candle[], series: Array<number | null>): LineData<Time>[] {
  const out: LineData<Time>[] = [];
  for (let i = 0; i < candles.length; i++) {
    const v = series[i];
    if (v == null) continue;
    out.push({ time: asTs(candles[i]!.time), value: v });
  }
  return out;
}

function lineOpts(
  series: ISeriesApi<"Candlestick">,
  existing: IPriceLine | null,
  price: number | null,
  title: string,
  color: string,
  dashed = true,
): IPriceLine | null {
  if (price == null) {
    if (existing) series.removePriceLine(existing);
    return null;
  }
  const opts = {
    price,
    title,
    color,
    lineWidth: 1 as const,
    lineStyle: dashed ? LineStyle.Dashed : LineStyle.SparseDotted,
    axisLabelVisible: true,
  };
  if (existing) {
    existing.applyOptions(opts);
    return existing;
  }
  return series.createPriceLine(opts);
}

export function ChartPanel({
  candles,
  analysis,
  plan,
}: {
  candles: Candle[];
  analysis: Analysis | null;
  plan: TradePlan | null;
}) {
  const hostRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const ema9Ref = useRef<ISeriesApi<"Line"> | null>(null);
  const ema21Ref = useRef<ISeriesApi<"Line"> | null>(null);
  const ema50Ref = useRef<ISeriesApi<"Line"> | null>(null);
  const ema200Ref = useRef<ISeriesApi<"Line"> | null>(null);
  const tfRef = useRef<string | null>(null);
  const linesRef = useRef<Record<string, IPriceLine | null>>({});
  const [hover, setHover] = useState<HoverOhlc | null>(null);

  useEffect(() => {
    const el = hostRef.current;
    if (!el) return;

    const chart = createChart(el, {
      width: el.clientWidth || 640,
      height: el.clientHeight || 288,
      layout: {
        background: { type: ColorType.Solid, color: palette.surface },
        textColor: palette.muted,
        fontFamily: "IBM Plex Sans, sans-serif",
        fontSize: 12,
        attributionLogo: false,
      },
      grid: {
        vertLines: { color: palette.grid },
        horzLines: { color: palette.grid },
      },
      crosshair: {
        mode: CrosshairMode.Normal,
        vertLine: { color: palette.subtle, width: 1, style: LineStyle.SparseDotted, labelBackgroundColor: palette.elevated },
        horzLine: { color: palette.subtle, width: 1, style: LineStyle.SparseDotted, labelBackgroundColor: palette.elevated },
      },
      rightPriceScale: {
        borderVisible: false,
        autoScale: true,
        scaleMargins: { top: 0.08, bottom: 0.12 },
      },
      timeScale: {
        borderVisible: false,
        timeVisible: true,
        secondsVisible: false,
      },
      handleScroll: { mouseWheel: true, pressedMouseMove: true, horzTouchDrag: true, vertTouchDrag: false },
      handleScale: { axisPressedMouseMove: true, mouseWheel: true, pinch: true },
    });

    const candlesSeries = chart.addSeries(CandlestickSeries, {
      upColor: palette.bull,
      downColor: palette.bear,
      borderUpColor: palette.bull,
      borderDownColor: palette.bear,
      wickUpColor: palette.bull,
      wickDownColor: palette.bear,
      priceLineVisible: true,
      lastValueVisible: true,
      priceFormat: { type: "price", precision: 2, minMove: 0.01 },
    });
    const lineBase = { priceLineVisible: false, lastValueVisible: false, crosshairMarkerVisible: false };
    const ema9 = chart.addSeries(LineSeries, { ...lineBase, color: palette.ema9, lineWidth: 1 });
    const ema21 = chart.addSeries(LineSeries, { ...lineBase, color: palette.ema21, lineWidth: 1 });
    const ema50 = chart.addSeries(LineSeries, { ...lineBase, color: palette.ema50, lineWidth: 1 });
    const ema200 = chart.addSeries(LineSeries, { ...lineBase, color: palette.ema200, lineWidth: 2 });

    chart.subscribeCrosshairMove((param: MouseEventParams<Time>) => {
      const data = param.seriesData.get(candlesSeries);
      if (!data || !("open" in data)) {
        setHover(null);
        return;
      }
      const t = typeof param.time === "number" ? param.time : 0;
      setHover({ time: t, open: data.open, high: data.high, low: data.low, close: data.close });
    });

    const ro = new ResizeObserver(() => {
      if (!el.clientWidth || !el.clientHeight) return;
      chart.applyOptions({ width: el.clientWidth, height: el.clientHeight });
    });
    ro.observe(el);

    chartRef.current = chart;
    candleRef.current = candlesSeries;
    ema9Ref.current = ema9;
    ema21Ref.current = ema21;
    ema50Ref.current = ema50;
    ema200Ref.current = ema200;

    return () => {
      ro.disconnect();
      chart.remove();
      chartRef.current = null;
      candleRef.current = null;
      tfRef.current = null;
      linesRef.current = {};
    };
  }, []);

  useEffect(() => {
    const candleSeries = candleRef.current;
    const chart = chartRef.current;
    if (!candleSeries || !chart || candles.length === 0) return;
    const tf = analysis?.timeframe ?? "H1";
    const reset = tfRef.current !== tf;
    tfRef.current = tf;

    if (reset) {
      const view = candles.slice(-180);
      const offset = candles.length - view.length;
      candleSeries.setData(view.map(toCandle));
      if (analysis) {
        ema9Ref.current?.setData(toLine(view, analysis.indicators.ema9Series.slice(offset)));
        ema21Ref.current?.setData(toLine(view, analysis.indicators.ema21Series.slice(offset)));
        ema50Ref.current?.setData(toLine(view, analysis.indicators.ema50Series.slice(offset)));
        ema200Ref.current?.setData(toLine(view, analysis.indicators.ema200Series.slice(offset)));
      }
      requestAnimationFrame(() => {
        chart.timeScale().fitContent();
      });
      return;
    }

    const last = candles[candles.length - 1]!;
    candleSeries.update(toCandle(last));
    const t = asTs(last.time);
    const i = candles.length - 1;
    if (analysis) {
      const { ema9Series, ema21Series, ema50Series, ema200Series } = analysis.indicators;
      if (ema9Series[i] != null) ema9Ref.current?.update({ time: t, value: ema9Series[i]! });
      if (ema21Series[i] != null) ema21Ref.current?.update({ time: t, value: ema21Series[i]! });
      if (ema50Series[i] != null) ema50Ref.current?.update({ time: t, value: ema50Series[i]! });
      if (ema200Series[i] != null) ema200Ref.current?.update({ time: t, value: ema200Series[i]! });
    }
  }, [candles, analysis]);

  useEffect(() => {
    const series = candleRef.current;
    if (!series) return;
    const support = analysis?.levels.find((l) => l.kind === "support")?.price ?? null;
    const resist = analysis?.levels.find((l) => l.kind === "resistance")?.price ?? null;
    const map = linesRef.current;
    map.entry = lineOpts(series, map.entry ?? null, plan?.entry ?? null, "Entry", palette.primary, true);
    map.sl = lineOpts(series, map.sl ?? null, plan?.stopLoss ?? null, "SL", palette.bear, true);
    map.tp1 = lineOpts(series, map.tp1 ?? null, plan?.takeProfit1 ?? null, "TP1", palette.bull, true);
    map.tp2 = lineOpts(series, map.tp2 ?? null, plan?.takeProfit2 ?? null, "TP2", palette.bull, true);
    map.sup = lineOpts(series, map.sup ?? null, support, "S", palette.bull, false);
    map.res = lineOpts(series, map.res ?? null, resist, "R", palette.bear, false);
  }, [analysis, plan]);

  const last = candles.at(-1);
  const ohlc = hover ?? (last ? { time: last.time, open: last.open, high: last.high, low: last.low, close: last.close } : null);
  const up = ohlc ? ohlc.close >= ohlc.open : true;

  return (
    <section className="flex min-h-0 flex-col overflow-hidden rounded-xl bg-card shadow-[var(--shadow-border)]">
      <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3">
        <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1 font-mono text-xs tabular-nums">
          {ohlc ? (
            <>
              <span className={cn("font-medium", up ? "text-bull" : "text-bear")}>
                O {formatPrice(ohlc.open)}
              </span>
              <span className="text-muted-foreground">H {formatPrice(ohlc.high)}</span>
              <span className="text-muted-foreground">L {formatPrice(ohlc.low)}</span>
              <span className={cn("font-medium", up ? "text-bull" : "text-bear")}>
                C {formatPrice(ohlc.close)}
              </span>
            </>
          ) : (
            <span className="text-muted-foreground">Loading tape…</span>
          )}
        </div>
        <ul className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
          <Legend className="bg-ema9" label="EMA 9" />
          <Legend className="bg-ema21" label="EMA 21" />
          <Legend className="bg-ema50" label="EMA 50" />
          <Legend className="bg-ema200" label="EMA 200" />
        </ul>
      </div>
      <div ref={hostRef} className="h-72 w-full md:h-chart" />
    </section>
  );
}

function Legend({ className, label }: { className: string; label: string }) {
  return (
    <li className="flex items-center gap-1.5">
      <span className={cn("h-px w-3", className)} />
      {label}
    </li>
  );
}

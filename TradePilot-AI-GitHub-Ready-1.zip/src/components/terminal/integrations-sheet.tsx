import { Cable, Radio } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { ADAPTERS, STRATEGIES } from "@/lib/market";
import { cn } from "@/lib/utils";

export function IntegrationsSheet() {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="sm" className="gap-2">
          <Cable className="size-4" />
          <span className="hidden sm:inline">Modules</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="overflow-y-auto">
        <SheetHeader>
          <SheetTitle>Modules</SheetTitle>
          <SheetDescription>
            TradePilot is built so the tape, the model, and news can be swapped without rewriting the desk. Execution stays off.
          </SheetDescription>
        </SheetHeader>
        <div className="flex flex-col gap-6 px-6 pb-8">
          <section>
            <p className="mb-3 text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">Data & intelligence</p>
            <ul className="flex flex-col gap-3">
              {ADAPTERS.map((a) => (
                <li key={a.id} className="rounded-lg bg-secondary p-4">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium">{a.label}</p>
                    <StatusChip live={a.status === "live"} />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">{a.blurb}</p>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{a.detail}</p>
                </li>
              ))}
            </ul>
          </section>
          <section>
            <p className="mb-3 text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">Strategies</p>
            <ul className="flex flex-col gap-3">
              {STRATEGIES.map((s) => (
                <li key={s.id} className="rounded-lg bg-secondary p-4">
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-sm font-medium">{s.name}</p>
                    <StatusChip live={s.status === "live"} />
                  </div>
                  <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{s.blurb}</p>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </SheetContent>
    </Sheet>
  );
}

function StatusChip({ live }: { live: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-1.5 text-xs", live ? "text-bull" : "text-muted-foreground")}>
      {live ? <Radio className="size-3" /> : <span className="size-1.5 rounded-full bg-muted-foreground/50" />}
      {live ? "Live" : "Ready"}
    </span>
  );
}

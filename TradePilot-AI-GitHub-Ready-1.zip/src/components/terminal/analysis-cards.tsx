import type { ReactNode } from "react";
import { Activity, GitBranch, Layers3, Milestone } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatPrice, type Analysis, type SignalSide } from "@/lib/market";
import { cn } from "@/lib/utils";

function sideBadge(side: SignalSide) {
  if (side === "BUY") return "bull" as const;
  if (side === "SELL") return "bear" as const;
  return "caution" as const;
}

export function AnalysisCards({ analysis }: { analysis: Analysis }) {
  const { indicators } = analysis;
  return (
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <Card title="Multi-timeframe" icon={<Layers3 className="size-3.5" />}>
        <ul className="flex flex-col gap-2">
          {analysis.mtf.map((v) => (
            <li key={v.timeframe} className="flex items-center justify-between gap-2 text-sm">
              <span className="font-mono text-xs text-muted-foreground">{v.timeframe}</span>
              <span className="min-w-0 flex-1 truncate text-xs text-muted-foreground">{v.note}</span>
              <Badge variant={sideBadge(v.side)}>{v.side}</Badge>
            </li>
          ))}
        </ul>
        <p className="mt-3 text-xs text-muted-foreground">
          Alignment {analysis.mtfAlignment}/4 on the active desk bias. H4 and H1 must agree before M5 is more than timing.
        </p>
      </Card>

      <Card title="Market structure" icon={<GitBranch className="size-3.5" />}>
        <p className="text-sm font-medium capitalize">{analysis.structure.bias}</p>
        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{analysis.structure.summary}</p>
        <dl className="mt-3 grid grid-cols-2 gap-2 font-mono text-xs tabular-nums">
          <div>
            <dt className="text-muted-foreground">Last swing high</dt>
            <dd className="text-bear">{analysis.structure.lastSwingHigh != null ? formatPrice(analysis.structure.lastSwingHigh) : "—"}</dd>
          </div>
          <div>
            <dt className="text-muted-foreground">Last swing low</dt>
            <dd className="text-bull">{analysis.structure.lastSwingLow != null ? formatPrice(analysis.structure.lastSwingLow) : "—"}</dd>
          </div>
        </dl>
        <ul className="mt-3 flex flex-wrap gap-1.5">
          {analysis.structure.swings.slice(-6).map((s) => (
            <li key={`${s.time}-${s.label}`}>
              <Badge variant={s.type === "high" ? "bear" : "bull"}>{s.label}</Badge>
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Support / resistance" icon={<Milestone className="size-3.5" />}>
        <ul className="flex flex-col gap-2">
          {analysis.levels.map((l) => (
            <li key={`${l.kind}-${l.price.toFixed(2)}`} className="flex items-center justify-between gap-2 text-sm">
              <span className={cn("text-xs font-medium", l.kind === "support" ? "text-bull" : "text-bear")}>
                {l.kind === "support" ? "S" : "R"}
              </span>
              <span className="font-mono text-xs tabular-nums">{formatPrice(l.price)}</span>
              <span className="text-xs text-muted-foreground">
                {formatPrice(l.distanceAbs)} {l.source === "round" ? "· round" : "· swing"}
              </span>
            </li>
          ))}
        </ul>
      </Card>

      <Card title="Indicators" icon={<Activity className="size-3.5" />}>
        <dl className="grid grid-cols-2 gap-x-3 gap-y-2 font-mono text-xs tabular-nums">
          <Metric label="EMA 9" value={indicators.ema9} />
          <Metric label="EMA 21" value={indicators.ema21} />
          <Metric label="EMA 50" value={indicators.ema50} />
          <Metric label="EMA 200" value={indicators.ema200} />
          <Metric label="RSI 14" value={indicators.rsi} digits={1} />
          <Metric label="ATR 14" value={indicators.atr} />
        </dl>
        <p className="mt-3 text-xs text-muted-foreground">
          ATR {indicators.atrPct != null ? `${indicators.atrPct.toFixed(2)}%` : "—"} of spot. Stops are 1.05–1.5× this, then structure.
        </p>
      </Card>
    </div>
  );
}

function Card({ title, icon, children }: { title: string; icon: ReactNode; children: ReactNode }) {
  return (
    <section className="rounded-xl bg-card p-4 shadow-[var(--shadow-border)]">
      <p className="mb-3 flex items-center gap-2 text-xs font-medium tracking-[0.16em] text-muted-foreground uppercase">
        {icon}
        {title}
      </p>
      {children}
    </section>
  );
}

function Metric({ label, value, digits = 2 }: { label: string; value: number | null; digits?: number }) {
  return (
    <div>
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="text-foreground">{value != null ? value.toFixed(digits) : "—"}</dd>
    </div>
  );
}

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { PaperTrade, Timeframe } from "@/lib/market";

interface TerminalState {
  timeframe: Timeframe;
  account: number;
  riskPct: number;
  paper: PaperTrade | null;
  setTimeframe: (tf: Timeframe) => void;
  setAccount: (n: number) => void;
  setRiskPct: (n: number) => void;
  trackPlan: (paper: PaperTrade) => void;
  markBreakeven: () => void;
  flatten: () => void;
}

export const useTerminal = create<TerminalState>()(
  persist(
    (set) => ({
      timeframe: "H1",
      account: 10000,
      riskPct: 0.5,
      paper: null,
      setTimeframe: (tf) => set({ timeframe: tf }),
      setAccount: (n) => set({ account: n }),
      setRiskPct: (n) => set({ riskPct: n }),
      trackPlan: (paper) => set({ paper }),
      markBreakeven: () =>
        set((s) => (s.paper ? { paper: { ...s.paper, status: "breakeven", stopLoss: s.paper.entry } } : s)),
      flatten: () => set({ paper: null }),
    }),
    { name: "tradepilot-prefs", skipHydration: true },
  ),
);

import { useMemo, useSyncExternalStore } from "react";
import {
  TIMEFRAMES,
  analyzeMarket,
  getDemoFeed,
  getFeedVersion,
  getServerFeedVersion,
  subscribeFeed,
  type Analysis,
  type Candle,
  type PaperTrade,
  type Quote,
  type Timeframe,
} from "@/lib/market";

export function useMarket(timeframe: Timeframe, paper: PaperTrade | null) {
  const version = useSyncExternalStore(subscribeFeed, getFeedVersion, getServerFeedVersion);
  const feed = version > 0 ? getDemoFeed() : null;

  const books = useMemo(() => {
    const map = {} as Record<Timeframe, Candle[]>;
    if (!feed) return map;
    for (const tf of TIMEFRAMES) map[tf] = feed.getCandles(tf);
    return map;
  }, [feed, version]);

  const candles = books[timeframe] ?? [];
  const quote: Quote | null = feed ? feed.quote() : null;

  const analysis: Analysis | null = useMemo(() => {
    if (!feed || !candles.length) return null;
    return analyzeMarket(timeframe, books, paper);
  }, [feed, timeframe, paper, candles.length, books]);

  return {
    ready: Boolean(feed && candles.length > 0 && analysis),
    version,
    candles,
    quote,
    analysis,
  };
}
